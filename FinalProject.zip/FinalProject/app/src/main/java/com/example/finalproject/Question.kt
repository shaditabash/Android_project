package com.example.finalproject

import java.util.ArrayList

class Question(var image: String, var choices: ArrayList<Choice>)