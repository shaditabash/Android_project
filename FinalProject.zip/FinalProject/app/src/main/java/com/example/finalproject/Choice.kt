package com.example.finalproject

class Choice(var choice: String, var correct: Boolean)