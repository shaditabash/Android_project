package com.example.finalproject

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.CountDownTimer
import android.os.Bundle
import android.media.MediaPlayer
import android.os.Handler
import android.util.Log
import android.view.View
import android.widget.*
import androidx.core.content.res.ResourcesCompat
import java.util.ArrayList

class MainActivity2 : AppCompatActivity() {
    private var questionArrayList = ArrayList<Question>()
    private var mCountDownTimer: CountDownTimer? = null
    private var scoreTV: TextView? = null
    private var hintBtn: Button? = null
    private var questionImage: ImageView? = null
    private var timerProgress: ProgressBar? = null
    private var choice1: Button? = null
    private var choice2: Button? = null
    private var choice3: Button? = null
    private var choice4: Button? = null
    private var i = 0
    private var currentQuestionIndex = 0
    private var score = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        scoreTV = findViewById(R.id.score_tv)
        hintBtn = findViewById(R.id.hint_btn)
        questionImage = findViewById(R.id.question_image)
        timerProgress = findViewById(R.id.progressBar)
        choice1 = findViewById(R.id.choice_1)
        choice2 = findViewById(R.id.choice_2)
        choice3 = findViewById(R.id.choice_3)
        choice4 = findViewById(R.id.choice_4)
        fillQuestions()
        fillData()
        hintBtn!!.setOnClickListener {
            if (choice1!!.visibility == View.VISIBLE && !questionArrayList[currentQuestionIndex].choices[0].correct) {
                choice1!!.visibility = View.GONE
            } else if (choice2?.visibility == View.VISIBLE && !questionArrayList[currentQuestionIndex].choices[1].correct) {
                choice2!!.visibility = View.GONE
            } else if (choice3?.visibility == View.VISIBLE && !questionArrayList[currentQuestionIndex].choices[2].correct) {
                choice3!!.visibility = View.GONE
            } else if (choice4?.visibility == View.VISIBLE && !questionArrayList[currentQuestionIndex].choices[3].correct) {
                choice4!!.visibility = View.GONE
            }
        }
        choice1!!.setOnClickListener { checkCorrectAnswer(0) }
        choice2!!.setOnClickListener{ checkCorrectAnswer(1) }
        choice3!!.setOnClickListener{ checkCorrectAnswer(2) }
        choice4!!.setOnClickListener{ checkCorrectAnswer(3) }
        runTimer()
    }

    private fun checkCorrectAnswer(btnClicked: Int) {
        var correctChoiceIndex = -1
        for (index in questionArrayList[currentQuestionIndex].choices.indices) {
            if (questionArrayList[currentQuestionIndex].choices[index].correct) {
                correctChoiceIndex = index
            }
        }
        when (correctChoiceIndex) {
            0 -> choice1!!.setBackgroundColor(Color.parseColor("#008000"))
            1 -> choice2!!.setBackgroundColor(Color.parseColor("#008000"))
            2 -> choice3!!.setBackgroundColor(Color.parseColor("#008000"))
            3 -> choice4!!.setBackgroundColor(Color.parseColor("#008000"))
        }
        if (btnClicked != correctChoiceIndex) {
            val mp = MediaPlayer.create(this, R.raw.buzzer)
            mp.start()
            when (btnClicked) {
                0 -> //                    choice1.setBackgroundResource(R.drawable.button_back_incorrect);
                    choice1!!.setBackgroundColor(Color.parseColor("#FF0000"))
                1 -> choice2!!.setBackgroundColor(Color.parseColor("#FF0000"))
                2 -> choice3!!.setBackgroundColor(Color.parseColor("#FF0000"))
                3 -> choice4!!.setBackgroundColor(Color.parseColor("#FF0000"))
            }
        } else {
            val mp = MediaPlayer.create(this, R.raw.claps)
            mp.start()
        }
        for (t in 0..3) {
            if (t != correctChoiceIndex && t != btnClicked) {
                when (t) {
                    0 -> choice1!!.setBackgroundColor(Color.parseColor("#f9f9f9"))
                    1 -> choice2!!.setBackgroundColor(Color.parseColor("#f9f9f9"))
                    2 -> choice3!!.setBackgroundColor(Color.parseColor("#f9f9f9"))
                    3 -> choice4!!.setBackgroundColor(Color.parseColor("#f9f9f9"))
                }
            }
        }
        val handler = Handler()
        val finalCorrectChoiceIndex = correctChoiceIndex
        handler.postDelayed({ determineTheAnswer(btnClicked, finalCorrectChoiceIndex) }, 5000)
    }

    private fun determineTheAnswer(btnClicked: Int, correctChoiceIndex: Int) {
        println("determineTheAnswer=>>>")
        if (btnClicked == correctChoiceIndex && currentQuestionIndex != questionArrayList.size - 1) {
            score += 5
            scoreTV!!.text = "Score: $score"
            nextQuestion()
        } else if (currentQuestionIndex == questionArrayList.size - 1) {
            if (btnClicked == correctChoiceIndex) {
                score += 5
                scoreTV!!.text = "Score: $score"
            }
            Toast.makeText(this, "تم الإنتهاء من الأسئلة", Toast.LENGTH_SHORT).show()
        } else if (currentQuestionIndex != questionArrayList.size - 1) {
            nextQuestion()
        }
    }

    private fun nextQuestion() {
        currentQuestionIndex++
        resetAll()
        fillData()
        resetTimer()
    }

    private fun fillQuestions() {
        val choicesArrayList = ArrayList<Choice>()
        choicesArrayList.add(Choice("Jazera", true))
        choicesArrayList.add(Choice("ARABIC", false))
        choicesArrayList.add(Choice("HADATH", false))
        choicesArrayList.add(Choice("CNN", false))
        questionArrayList.add(Question("aljazera", choicesArrayList))
        val choices2ArrayList = ArrayList<Choice>()
        choices2ArrayList.add(Choice("Jazera", false))
        choices2ArrayList.add(Choice("ARABIC", true))
        choices2ArrayList.add(Choice("HADATH", false))
        choices2ArrayList.add(Choice("CNN", false))
        questionArrayList.add(Question("arabiya", choices2ArrayList))
        val choices3ArrayList = ArrayList<Choice>()
        choices3ArrayList.add(Choice("Jazera", false))
        choices3ArrayList.add(Choice("ARABIC", false))
        choices3ArrayList.add(Choice("HADATH", true))
        choices3ArrayList.add(Choice("CNN", false))
        questionArrayList.add(Question("hadath", choices3ArrayList))
    }

    private fun fillData() {
        val imageId = resources.getIdentifier(
            questionArrayList[currentQuestionIndex].image,
            "drawable",
            packageName
        )
        val drawable = ResourcesCompat.getDrawable(resources, imageId, null)
        questionImage!!.setImageDrawable(drawable)
        choice1!!.text = questionArrayList[currentQuestionIndex].choices[0].choice
        choice2!!.text = questionArrayList[currentQuestionIndex].choices[1].choice
        choice3!!.text = questionArrayList[currentQuestionIndex].choices[2].choice
        choice4!!.text = questionArrayList[currentQuestionIndex].choices[3].choice
    }

    private fun runTimer() {
        mCountDownTimer = object : CountDownTimer(5000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                Log.v("Log_tag", "Tick of Progress$i$millisUntilFinished")
                i++
                timerProgress!!.progress = i * 100 / (5000 / 1000)
            }

            override fun onFinish() {
                //Do what you want
//                i++;
//                timerProgress.setProgress(100);
//
//                if(currentQuestionIndex < (questionArrayList.size() - 1)){
//                    resetTimer();
//                }
            }
        }
        (mCountDownTimer as CountDownTimer).start()
    }

    private fun resetTimer() {
        i = 0
        timerProgress!!.progress = 0
        runTimer()
    }

    private fun resetAll() {
        choice1!!.visibility = View.VISIBLE
        choice2!!.visibility = View.VISIBLE
        choice3!!.visibility = View.VISIBLE
        choice4!!.visibility = View.VISIBLE
        choice1!!.setBackgroundColor(Color.parseColor("#d8d8d8"))
        choice2!!.setBackgroundColor(Color.parseColor("#d8d8d8"))
        choice3!!.setBackgroundColor(Color.parseColor("#d8d8d8"))
        choice4!!.setBackgroundColor(Color.parseColor("#d8d8d8"))
    }
}